Consumer Price Index for *All Urban Consumers (CPI-U)* from U.S. Department
Of Labor Bureau of Labor Statistics. This is a monthly time series from January 1913. Values are U.S. city averages for all items and
1982-84=100. Note that there are many price indices and this is only one of
them (albeit the most standard and with the longest set of data).

## Data

Data is sourced from <ftp://ftp.bls.gov/pub/special.requests/cpi/cpiai.txt> and normalized into a CSV.

## License

This Data Package is made available under the Public Domain Dedication and License v1.0 whose full text can be found at: http://www.opendatacommons.org/licenses/pddl/1.0/